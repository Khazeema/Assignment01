package com.snovia.assignmentone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;



public class  MainActivity2 extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        findViewById(R.id.apple).setOnClickListener(this::onClick);
        findViewById(R.id.orange).setOnClickListener(this::onClick);
        findViewById(R.id.banana).setOnClickListener(this::onClick);
        findViewById(R.id.grapes).setOnClickListener(this::onClick);
        findViewById(R.id.strawberry).setOnClickListener(this::onClick);
        findViewById(R.id.peech).setOnClickListener(this::onClick);
        findViewById(R.id.mango).setOnClickListener(this::onClick);
    }
    public void onClick(View view){
        Intent[] i = new Intent[7];
        switch(view.getId()) {
            case R.id.apple:
                i[0] = new Intent(this,MainActivity3.class);
                i[0].putExtra("name","apple");
                startActivity(i[0]);
                break;
            case R.id.orange:
                i[1] = new Intent(this,MainActivity3.class);
                i[1].putExtra("name","orange");
                startActivity(i[1]);
                break;
            case R.id.banana:
                i[2] = new Intent(this,MainActivity3.class);
                i[2].putExtra("name","banana");
                startActivity(i[2]);
                break;
            case R.id.grapes:
                i[3] = new Intent(this,MainActivity3.class);
                i[3].putExtra("name","grapes");
                startActivity(i[3]);
                break;
            case R.id.strawberry:
                i[4] = new Intent(this,MainActivity3.class);
                i[4].putExtra("name","strawberry");
                startActivity(i[4]);
                break;
            case R.id.peech:
                i[5] = new Intent(this,MainActivity3.class);
                i[5].putExtra("name","peech");
                startActivity(i[5]);
                break;
            default:
                i[6] = new Intent(this,MainActivity3.class);
                i[6].putExtra("name","mango");
                startActivity(i[6]);
                break;
        }
    }
}