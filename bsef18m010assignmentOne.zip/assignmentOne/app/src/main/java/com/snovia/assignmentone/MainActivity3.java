package com.snovia.assignmentone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {

    ImageView iv;
    MediaPlayer mp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        String value = getIntent().getStringExtra("name");
        showImage(value);

    }
    public void showImage(String value){
        Drawable[] new_image = new Drawable[7];
        switch (value){
            case "apple":
                iv = (ImageView)findViewById(R.id.default_img);
                new_image[0]= getResources().getDrawable(R.drawable.apple);
                iv.setImageDrawable(new_image[0]);
                mp = MediaPlayer.create(this,R.raw.a);
                mp.start();
                iv.animate().rotation(720).setDuration(2000);
                break;
            case "orange":
                iv = (ImageView)findViewById(R.id.default_img);
                new_image[1]= getResources().getDrawable(R.drawable.orange);
                iv.setImageDrawable(new_image[1]);
                mp = MediaPlayer.create(this,R.raw.o);
                mp.start();
                iv.animate().rotation(720).setDuration(2000);
                break;
            case "banana":
                iv = (ImageView)findViewById(R.id.default_img);
                new_image[2]= getResources().getDrawable(R.drawable.banana);
                iv.setImageDrawable(new_image[2]);
                mp = MediaPlayer.create(this,R.raw.b);
                mp.start();
                iv.animate().rotation(720).setDuration(2000);
                break;
            case "grapes":
                iv = (ImageView)findViewById(R.id.default_img);
                new_image[3]= getResources().getDrawable(R.drawable.grapes);
                iv.setImageDrawable(new_image[3]);
                mp = MediaPlayer.create(this,R.raw.g);
                mp.start();
                iv.animate().rotation(720).setDuration(2000);
                break;
            case "mango":
                iv = (ImageView)findViewById(R.id.default_img);
                new_image[4]= getResources().getDrawable(R.drawable.m);
                iv.setImageDrawable(new_image[4]);
                mp = MediaPlayer.create(this,R.raw.m);
                mp.start();
                iv.animate().rotation(720).setDuration(2000);
                break;
            case "peech":
                iv = (ImageView)findViewById(R.id.default_img);
                new_image[5]= getResources().getDrawable(R.drawable.p);
                iv.setImageDrawable(new_image[5]);
                mp = MediaPlayer.create(this,R.raw.p);
                mp.start();
                iv.animate().rotation(720).setDuration(2000);
                break;
            default:
                iv = (ImageView)findViewById(R.id.default_img);
                new_image[6]= getResources().getDrawable(R.drawable.s);
                iv.setImageDrawable(new_image[6]);
                mp = MediaPlayer.create(this,R.raw.f);
                mp.start();
                iv.animate().rotation(720).setDuration(2000);
                break;
        }
    }

}